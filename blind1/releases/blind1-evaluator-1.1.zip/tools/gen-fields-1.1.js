// Таблица полей для пакета автора 1.1: ВСЕ исходные поля словаря одним списком по алфавиту,
// без указания, какие поля извлекает программа, и без признака «критическое» (условие независимости автора).
// Разделение на часть A/B хранится только у оценщика (field-sets.json, заморожен).
'use strict';
const fs = require('fs'), path = require('path');
const R = require(path.join(process.argv[2], 'rules/pilot-rules.json'));
const dd = R.data_dictionary;
const esc = s => String(s == null ? '' : s).replace(/\|/g, '/').replace(/\n/g, ' ');
const T = { number: 'число', tri: 'да/нет', text: 'текст', enum: 'перечень', datetime: 'дата-время', list: 'список', object: 'объект', date: 'дата' };
const raw = Object.entries(dd).filter(([, v]) => v.type !== 'derived').sort((a, b) => a[0].localeCompare(b[0]));
const rows = raw.map(([k, v]) => `| \`${k}\` | ${esc(v.description)} | ${T[v.type] || v.type} | ${esc(v.values ? v.values.join(', ') : v.unit || '')} |`);
fs.writeFileSync(process.argv[3], `Всего ${raw.length} полей.\n\n| Поле | Описание (не образец формулировки!) | Тип | Единица / допустимые значения |\n|---|---|---|---|\n${rows.join('\n')}\n`);
console.log(raw.length);
