// Генерирует таблицы полей для пакета автора из rules/pilot-rules.json (data_dictionary).
// Часть A — схема извлечения (поля, которые программа заявляет как извлекаемые; только имена, без шаблонов).
// Часть B — остальные исходные поля словаря. Производные (type=derived) не передаются.
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = process.argv[2];
const R = require(path.join(ROOT, 'rules/pilot-rules.json'));
const E = require(path.join(ROOT, 'engine/extract/extract.js'));
const src = fs.readFileSync(path.join(ROOT, 'engine/extract/extract.js'), 'utf8');
const A = new Set([...src.matchAll(/f: '([a-z0-9_]+)'/g)].map(m => m[1]));
const dd = R.data_dictionary;
const esc = s => String(s == null ? '' : s).replace(/\|/g, '/').replace(/\n/g, ' ');
const T = { number: 'число', tri: 'да/нет', text: 'текст', enum: 'перечень', datetime: 'дата-время', list: 'список', object: 'объект', date: 'дата' };
function row(k, v) {
  const vals = v.values ? v.values.join(', ') : (v.unit || '');
  return `| \`${k}\` | ${esc(v.description)} | ${T[v.type] || v.type} | ${esc(vals)} | ${E.CRITICAL.test(k) ? 'да' : ''} |`;
}
const head = '| Поле | Описание (не образец формулировки!) | Тип | Единица / допустимые значения | Критическое |\n|---|---|---|---|---|';
const raw = Object.entries(dd).filter(([, v]) => v.type !== 'derived');
const a = raw.filter(([k]) => A.has(k)), b = raw.filter(([k]) => !A.has(k));
let out = `### Часть A — схема извлечения (${a.length} полей)\n\n${head}\n${a.map(([k, v]) => row(k, v)).join('\n')}\n\n`;
out += `### Часть B — прочие исходные поля словаря (${b.length} полей)\n\nРазмечаются, если сведения есть в истории; в основную полноту не входят (раздел «недостающие сведения»).\n\n${head}\n${b.map(([k, v]) => row(k, v)).join('\n')}\n`;
const rules = R.rules.map(r => `| ${r.rule_id} | ${{ rds: 'РДС', nek: 'НЭК', sepsis: 'Сепсис' }[r.protocol]} | ${esc(r.requirement.description)} |`).join('\n');
fs.writeFileSync(process.argv[3], out);
fs.writeFileSync(process.argv[4], `| Правило | Протокол | Требование |\n|---|---|---|\n${rules}\n`);
fs.writeFileSync(process.argv[5], JSON.stringify({ partA: a.map(([k]) => k), partB: b.map(([k]) => k), critical: a.map(([k]) => k).filter(k => E.CRITICAL.test(k)) }, null, 1) + '\n');
console.log('A', a.length, 'B', b.length);
