// Антидефект — слепое тестирование №1. Сопоставление кандидатов извлечения с эталоном одной истории.
// Реализует раздел 4 метода blind1-method-1.1. Не зависит от устройства извлекателя: читает только его вывод.
'use strict';
const C = require('./common.js');

const READABLE = new Set(['body', 'table']);
const DOSE = /_dose_|surfactant_initial_dose/;
const TIME_TRAPS = new Set(['time_without_date', 'date_without_time', 'relative_time', 'midnight_crossing']);
const DOSE_TRAPS = new Set(['unit_not_field_unit', 'dose_without_unit']);
const NEG_TRAPS = new Set(['negation', 'plan', 'conditional']);

function subclass(f, type) {
  if (DOSE.test(f)) return 'доза';
  return { number: 'число', datetime: 'время', date: 'время', tri: 'да/нет', enum: 'перечень', text: 'текст' }[type] || 'значение';
}
const timeOf = (f, e) => (f === 'vent_changes' || f === 'xrays') ? e.at : e.drawn_at;

/** Значения кандидатов поля: [{v (сырое), c (каноническое), frs:[{start,end}], single, kind}] */
function candValues(cands, f, type) {
  const out = [];
  for (const c of cands.filter(x => x.field === f)) {
    if (C.isList(f)) {
      (c.value || []).forEach((e, i) => out.push({ v: e, c: C.canonElem(f, e), frs: [(c.fragments || [])[i] || c].filter(Boolean), single: true, kind: 'элемент', cid: c.id }));
    } else if (c.timeline) {
      for (const t of c.timeline) out.push({ v: t.v, c: t.v, at: t.at || null, date: t.date || null, frs: [t.fragment], single: true, kind: 'наблюдение', cid: c.id });
    } else if (c.alternatives) {
      for (const a of c.alternatives) out.push({ v: a.value, c: C.canon(a.value, type), frs: a.fragments || [], single: false, kind: 'альтернатива', cid: c.id });
    } else {
      out.push({ v: c.value, c: C.canon(c.value, type), frs: c.fragments || [{ start: c.start, end: c.end }], single: true, kind: 'значение', cid: c.id });
    }
  }
  return out;
}

/**
 * scoreHistory({h, text, extraction, dd, sets}) — h: история эталона; text — текст, поданный в extract();
 * extraction — вывод extract(); dd — data_dictionary; sets — {partA, critical}.
 */
function scoreHistory({ h, text, extraction, dd, sets }) {
  const partA = new Set(sets.partA), critical = new Set(sets.critical);
  const cands = extraction.candidates || [];
  const units = [], lp = [], dateOnly = [], unreadFacts = [];
  const quoteSpans = q => C.spans(text, q).map(([s, e]) => [s, e]);
  const fragHits = (frs, facts) => {
    const sp = facts.flatMap(f => quoteSpans(f.quote));
    return frs.some(fr => fr && sp.some(s => C.overlap([fr.start, fr.end], s)));
  };
  const factsA = h.facts.filter(f => partA.has(f.field)); // часть A определяется по словарю (field-sets.json), а не автором
  for (const f of factsA) if (!READABLE.has(f.location)) unreadFacts.push({ fid: f.fid, field: f.field, location: f.location });
  const fields = new Set([...factsA.map(f => f.field), ...cands.map(c => c.field)]);

  for (const F of fields) {
    const type = (dd[F] || {}).type;
    const all = factsA.filter(f => f.field === F && READABLE.has(f.location));
    const cur = all.filter(f => f.record_status !== 'superseded');
    const sup = all.filter(f => f.record_status === 'superseded');
    const cv = candValues(cands, F, type);
    const used = new Set();
    const mk = (u) => { u.history = h.id; u.field = F; u.critical = critical.has(F); u.type = type; units.push(u); return u; };

    if (C.isList(F)) {
      const gu = []; for (const f of cur) { const e = C.canonElem(F, f.value), k = C.LIST_KEY[F](e); let u = gu.find(x => x.key === k); if (!u) gu.push(u = { key: k, elem: e, facts: [] }); u.facts.push(f); }
      const supE = sup.map(f => C.canonElem(F, f.value));
      const pending = [];
      for (const u of gu) {
        const i = cv.findIndex((v, j) => !used.has(j) && C.LIST_KEY[F](v.c) === u.key);
        if (i < 0) { pending.push(u); continue; }
        used.add(i); const v = cv[i];
        const bad = Object.keys(u.elem).filter(k => !C.same(u.elem[k], v.c[k] === undefined ? null : v.c[k]));
        mk({ key: u.key, expected: u.elem, got: v.v, cls: bad.length ? 'О' : 'В', sub: bad.length ? 'свойства: ' + bad.join(', ') : null, silent: bad.length > 0, timeErr: false, fragOk: fragHits(v.frs, u.facts), fids: u.facts.map(f => f.fid), quote: u.facts[0].quote });
      }
      for (const u of pending) { // ключ (время) не совпал: ищем элемент с теми же прочими свойствами → ошибка времени
        const i = cv.findIndex((v, j) => !used.has(j) && Object.keys(u.elem).filter(k => !/^(at|drawn_at)$/.test(k)).every(k => C.same(u.elem[k], v.c[k] === undefined ? null : v.c[k])));
        if (i >= 0) { used.add(i); mk({ key: u.key, expected: u.elem, got: cv[i].v, cls: 'О', sub: 'время элемента', silent: true, timeErr: true, fragOk: fragHits(cv[i].frs, u.facts), fids: u.facts.map(f => f.fid), quote: u.facts[0].quote }); }
        else mk({ key: u.key, expected: u.elem, got: null, cls: 'П', fids: u.facts.map(f => f.fid), quote: u.facts[0].quote });
      }
      cv.forEach((v, j) => { if (!used.has(j)) lp.push({ history: h.id, field: F, got: v.v, single: true, superseded: supE.some(e => C.same(e, v.c)), frs: v.frs }); });
      continue;
    }

    if (F === 'gi_passage_restored') {
      const gu = []; for (const f of cur) { const t = f.event_at || null, d = f.event_date || (t ? t.slice(0, 10) : null); if (!gu.some(u => u.v === f.value && u.at === t && u.date === d)) gu.push({ v: f.value, at: t, date: d, facts: cur.filter(x => x.value === f.value && (x.event_at || null) === t) }); }
      const hit = (u, v) => v.c === u.v && (u.at ? v.at === u.at : (!v.at && v.date === u.date));
      const pending = [];
      for (const u of gu) { const i = cv.findIndex((v, j) => !used.has(j) && hit(u, v)); if (i < 0) { pending.push(u); continue; } used.add(i); mk({ key: `${u.v}@${u.at || u.date}`, expected: u.v, got: cv[i].v, cls: 'В', fragOk: fragHits(cv[i].frs, u.facts), fids: u.facts.map(f => f.fid), quote: u.facts[0].quote }); }
      for (const u of pending) {
        const i = cv.findIndex((v, j) => !used.has(j) && (v.date === u.date || (v.at && u.at && v.at.slice(0, 10) === u.at.slice(0, 10))));
        if (i >= 0) { used.add(i); const v = cv[i]; const te = v.c === u.v; mk({ key: `${u.v}@${u.at || u.date}`, expected: { v: u.v, at: u.at, date: u.date }, got: { v: v.c, at: v.at, date: v.date }, cls: 'О', sub: te ? 'время' : 'да/нет', silent: true, timeErr: te, negErr: !te && v.c === true && u.v === false, fids: u.facts.map(f => f.fid), quote: u.facts[0].quote }); }
        else mk({ key: `${u.v}@${u.at || u.date}`, expected: u.v, got: null, cls: 'П', fids: u.facts.map(f => f.fid), quote: u.facts[0].quote });
      }
      cv.forEach((v, j) => { if (!used.has(j)) lp.push({ history: h.id, field: F, got: { v: v.c, at: v.at, date: v.date }, single: true, superseded: false, frs: v.frs }); });
      continue;
    }

    // обычное поле
    const nullDate = cur.filter(f => f.value === null || f.value === undefined);
    for (const f of nullDate) {
      const sp = quoteSpans(f.quote);
      const inv = cv.filter(v => v.v !== null && v.frs.some(fr => fr && sp.some(s => C.overlap([fr.start, fr.end], s))));
      dateOnly.push({ history: h.id, field: F, fid: f.fid, quote: f.quote, invented: inv.map(v => ({ got: v.v, single: v.single })) });
      inv.forEach(v => used.add(cv.indexOf(v)));
    }
    const gu = [];
    for (const f of cur.filter(f => f.value !== null && f.value !== undefined)) { const c = C.canon(f.value, type); let u = gu.find(x => C.same(x.c, c)); if (!u) gu.push(u = { c, v: f.value, facts: [] }); u.facts.push(f); }
    const supC = sup.map(f => C.canon(f.value, type));
    const pending = [];
    for (const u of gu) {
      const si = cv.findIndex((v, j) => !used.has(j) && v.single && C.same(v.c, u.c));
      const ai = si >= 0 ? -1 : cv.findIndex((v, j) => !used.has(j) && !v.single && C.same(v.c, u.c));
      const i = si >= 0 ? si : ai;
      if (i < 0) { pending.push(u); continue; }
      used.add(i);
      mk({ key: JSON.stringify(u.c), expected: u.v, got: cv[i].v, cls: si >= 0 ? 'В' : 'ВА', fragOk: fragHits(cv[i].frs, u.facts), fids: u.facts.map(f => f.fid), quote: u.facts[0].quote });
    }
    const wrong = cv.map((v, j) => ({ v, j })).filter(({ v, j }) => !used.has(j) && !supC.some(s => C.same(s, v.c)));
    for (const u of pending) {
      const w = wrong.shift();
      if (w) {
        used.add(w.j);
        mk({ key: JSON.stringify(u.c), expected: u.v, got: w.v.v, cls: 'О', sub: subclass(F, type), silent: w.v.single, timeErr: type === 'datetime' || type === 'date', doseErr: DOSE.test(F), negErr: type === 'tri' && u.c === false && w.v.c === true, fragOk: fragHits(w.v.frs, u.facts), fids: u.facts.map(f => f.fid), quote: u.facts[0].quote });
      } else mk({ key: JSON.stringify(u.c), expected: u.v, got: null, cls: 'П', fids: u.facts.map(f => f.fid), quote: u.facts[0].quote });
    }
    cv.forEach((v, j) => { if (!used.has(j)) lp.push({ history: h.id, field: F, got: v.v, single: v.single, superseded: supC.some(s => C.same(s, v.c)), frs: v.frs, timeField: type === 'datetime' || type === 'date', doseField: DOSE.test(F) }); });
  }

  // ловушки
  const traps = (h.traps || []).map(t => {
    const sp = quoteSpans(t.quote);
    const type = (dd[t.field] || {}).type;
    if (t.type === 'deleted_tracked_text') { // удалённый текст не должен попасть в прочитанный текст
      const leaked = sp.length > 0;
      return { tid: t.tid, history: h.id, type: t.type, field: t.field, quote: t.quote, status: leaked ? 'сработала' : 'выдержана', triggered: leaked ? [{ got: 'удалённый текст в прочитанном тексте', single: true }] : [] };
    }
    if (!READABLE.has(t.location || 'body')) return { tid: t.tid, history: h.id, type: t.type, field: t.field, status: 'в непрочитываемом месте', triggered: [] };
    if (!sp.length) return { tid: t.tid, history: h.id, type: t.type, field: t.field, status: 'не проверяема: цитата не найдена в поданном тексте', triggered: [] };
    const cv = t.field ? candValues(cands, t.field, type) : [];
    const mnv = t.must_not_value;
    const trig = cv.filter(v => v.frs.some(fr => fr && sp.some(s => C.overlap([fr.start, fr.end], s))) &&
      (mnv === 'any' || C.same(v.c, C.isList(t.field) ? C.canonElem(t.field, mnv) : C.canon(mnv, type))));
    return { tid: t.tid, history: h.id, type: t.type, field: t.field, quote: t.quote, status: trig.length ? 'сработала' : 'выдержана', triggered: trig.map(v => ({ got: v.v, single: v.single })) };
  });
  // ЛП: тип по пересекающимся ловушкам
  for (const x of lp) {
    const tt = (h.traps || []).filter(t => t.field === x.field && C.spans(text, t.quote).some(s => x.frs.some(fr => fr && C.overlap([fr.start, fr.end], s))));
    x.trap_types = tt.map(t => t.type); x.kind = x.superseded ? 'устаревшее значение' : tt.length ? tt.map(t => t.type).join('+') : 'не объяснено';
  }
  return { history: h.id, protocol: h.protocol, format: h.format, units, lp, traps, dateOnly, unreadFacts };
}

/** Сводка нулевых критериев по истории: {criterion: {k, n, items[]}} */
function zeroCounts(r) {
  const z = { dose: { k: 0, n: 0, items: [] }, time: { k: 0, n: 0, items: [] }, negplan: { k: 0, n: 0, items: [] } };
  for (const u of r.units) {
    if (DOSE.test(u.field)) { z.dose.n++; if (u.cls === 'О' && u.silent) { z.dose.k++; z.dose.items.push(u); } }
    const timey = u.type === 'datetime' || u.type === 'date' || (C.isList(u.field)) || u.field === 'gi_passage_restored';
    if (timey) { z.time.n++; if (u.cls === 'О' && u.silent && u.timeErr) { z.time.k++; z.time.items.push(u); } }
    if (u.type === 'tri' && JSON.parse(u.key) === false) { z.negplan.n++; if (u.negErr) { z.negplan.k++; z.negplan.items.push(u); } }
  }
  for (const d of r.dateOnly) { z.time.n++; if (d.invented.some(v => v.single)) { z.time.k++; z.time.items.push(d); } }
  for (const t of r.traps) {
    const checkable = t.status === 'сработала' || t.status === 'выдержана';
    if (!checkable) continue;
    if (DOSE_TRAPS.has(t.type)) { z.dose.n++; if (t.triggered.some(v => v.single)) { z.dose.k++; z.dose.items.push(t); } }
    if (TIME_TRAPS.has(t.type)) { z.time.n++; if (t.triggered.some(v => v.single)) { z.time.k++; z.time.items.push(t); } }
    if (NEG_TRAPS.has(t.type)) { z.negplan.n++; if (t.triggered.length) { z.negplan.k++; z.negplan.items.push(t); } }
  }
  return z;
}

module.exports = { scoreHistory, zeroCounts, candValues, READABLE, DOSE };
