// Сквозная проверка оценщика на техническом примере test/tech (не клинический набор).
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const cp = require('child_process'), fs = require('fs'), path = require('path'), os = require('os');
const REPO = process.env.ANTIDEFECT_REPO || '/home/claude/antidefect';
const S = path.resolve(__dirname, '..'), TECH = path.join(__dirname, 'tech'), SETS = path.join(S, '..', 'field-sets.json'), MAN = path.join(S, '..', 'freeze', 'program-manifest.json');
const run = (args, ok = true) => { const r = cp.spawnSync(process.execPath, args, { cwd: S, encoding: 'utf8' }); if (ok) assert.equal(r.status, 0, r.stderr + r.stdout); return r; };
const val = input => cp.spawnSync('python3', ['-I', path.join(S, 'validate.py'), '--input', input, '--dict', path.join(REPO, 'rules/pilot-rules.json'), '--sets', SETS, '--technical-test'], { encoding: 'utf8' });

test('формальная проверка: технический пример проходит; искажённая цитата и неверный тип — замечания', () => {
  assert.equal(val(TECH).status, 0);
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'b1v-')); fs.cpSync(TECH, d, { recursive: true });
  const g = JSON.parse(fs.readFileSync(path.join(d, 'blind1-gold.json'), 'utf8'));
  g.histories[0].facts[0].quote = 'нет такого текста'; g.histories[0].facts[1].value = '1250';
  g.histories[1].facts[0].location = 'table';
  fs.writeFileSync(path.join(d, 'blind1-gold.json'), JSON.stringify(g));
  const r = val(d); assert.equal(r.status, 1);
  const e = JSON.parse(r.stdout).errors.join('\n');
  assert.match(e, /цитата не найдена/); assert.match(e, /не соответствует типу number/); assert.match(e, /ТЕХ-02\/Т2-F1: цитата не найдена в месте table/);
});

test('прогон и оценка: без заморозки — отказ; повторный прогон и повторная оценка — отказ; результаты только для чтения', () => {
  const out = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'b1r-')), 'res');
  const noFreeze = run(['run.js', '--repo', REPO, '--input', TECH, '--manifest', MAN, '--out', out], false);
  assert.equal(noFreeze.status, 2); assert.match(noFreeze.stderr, /нет --freeze/);
  run(['run.js', '--repo', REPO, '--input', TECH, '--manifest', MAN, '--out', out, '--technical-test']);
  assert.equal(run(['run.js', '--repo', REPO, '--input', TECH, '--manifest', MAN, '--out', out, '--technical-test'], false).status, 2);
  run(['score.js', '--repo', REPO, '--input', TECH, '--sets', SETS, '--results', out]);
  assert.notEqual(run(['score.js', '--repo', REPO, '--input', TECH, '--sets', SETS, '--results', out], false).status, 0);
  const m = JSON.parse(fs.readFileSync(path.join(out, 'metrics.json'), 'utf8'));
  assert.equal(m.extraction_e2e.recall.n, 8); assert.equal(m.unread_facts, 2);
  assert.equal(m.docx_reading.unread_detection.k, 4); assert.equal(m.docx_reading.false_warnings, 0);
  assert.equal(m.zero.dose.status, 'не проверен');
  assert.equal(m.traps.deleted_tracked_text['выдержана'], 1);
  const man = JSON.parse(fs.readFileSync(path.join(out, 'MANIFEST.json'), 'utf8'));
  assert.ok(man.files['report.md'] && man.files['extraction/ТЕХ-02.json']);
  assert.equal(fs.statSync(path.join(out, 'metrics.json')).mode & 0o222, 0);
});

test('прогон с заморозкой: изменённый входной файл — отказ', () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'b1f-')); fs.cpSync(TECH, d, { recursive: true });
  const frz = path.join(d, 'freeze.json');
  fs.writeFileSync(frz, JSON.stringify({ input_files: { 'blind1-gold.json': 'неверный' } }));
  const r = run(['run.js', '--repo', REPO, '--input', d, '--manifest', MAN, '--freeze', frz, '--out', path.join(d, 'res')], false);
  assert.equal(r.status, 2); assert.match(r.stderr, /не совпадает с заморозкой/);
});
