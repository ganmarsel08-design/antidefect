#!/usr/bin/env node
// Антидефект — слепое тестирование №1. ПРОГОН неизменной программы (раздел 2, шаг 5 метода 1.1).
// node run.js --repo <рабочая копия> --input <распакованный архив> --manifest <program-manifest.json> --freeze <blind1-freeze.json> --out <results-v1>
// Отказ, если: хэши программы или входных файлов не совпадают с заморозкой; каталог результатов уже существует.
'use strict';
const fs = require('fs'), path = require('path'), cp = require('child_process');
const C = require('./common.js');
const R = require('./reading.js');

const arg = k => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : null; };
const die = m => { console.error('ОСТАНОВ: ' + m); process.exit(2); };

async function main() {
  const repo = path.resolve(arg('repo')), input = path.resolve(arg('input')), out = path.resolve(arg('out'));
  const man = JSON.parse(fs.readFileSync(arg('manifest'), 'utf8'));
  const frz = arg('freeze') ? JSON.parse(fs.readFileSync(arg('freeze'), 'utf8')) : null;
  if (fs.existsSync(out)) die(`каталог результатов уже существует: ${out} (первый прогон выполняется один раз)`);
  // 1. программа
  const head = cp.execSync('git rev-parse HEAD', { cwd: repo }).toString().trim();
  if (head !== man.base_commit) die(`HEAD ${head} ≠ базовый коммит ${man.base_commit}`);
  for (const [f, h] of Object.entries(man.files)) { const a = C.sha256File(path.join(repo, f)); if (a !== h) die(`хэш программы не совпадает: ${f}`); }
  // 2. входные данные
  if (frz) for (const [f, h] of Object.entries(frz.input_files)) { const a = C.sha256File(path.join(input, f)); if (a !== h) die(`хэш входного файла не совпадает с заморозкой: ${f}`); }
  else if (!process.argv.includes('--technical-test')) die('нет --freeze: прогон без заморозки разрешён только для технических примеров (--technical-test)');
  const X = require(path.join(repo, 'engine/extract/extract.js'));
  const DX = require(path.join(repo, 'engine/extract/docx.js'));
  const JSZip = require(path.join(repo, 'engine/vendor/jszip/jszip.min.js'));
  const gold = JSON.parse(fs.readFileSync(path.join(input, 'blind1-gold.json'), 'utf8'));
  const tz = gold.facility_utc_offset;
  fs.mkdirSync(path.join(out, 'extraction'), { recursive: true });
  for (const h of gold.histories) {
    const p = path.join(input, 'histories', h.file);
    const rec = { id: h.id, file: h.file, format: h.format, extract_version: X.VERSION, tz };
    if (h.format === 'txt') {
      rec.text = C.normText(fs.readFileSync(p, 'utf8'));
      rec.extraction = X.extract(rec.text, { tz, documentId: h.file });
    } else {
      try {
        const r = await DX.readDocx(fs.readFileSync(p), { JSZip });
        rec.text = r.text; rec.docx = { warnings: r.warnings, complete: r.complete, stats: r.stats };
        rec.extraction = X.extract(r.text, { tz, documentId: h.file, warnings: r.warnings });
      } catch (e) { rec.docx = { error: e.code || 'ERROR', message: e.message }; rec.text = ''; rec.extraction = { candidates: [], warnings: [] }; }
      const refp = path.join(input, 'docx-text', h.id + '.json');
      if (fs.existsSync(refp)) {
        const ref = JSON.parse(fs.readFileSync(refp, 'utf8'));
        const t = R.refText(ref);
        rec.ref = { text: t, extraction: X.extract(t, { tz, documentId: h.id + ' (эталон чтения)' }) };
      } else rec.ref = { missing: true };
    }
    fs.writeFileSync(path.join(out, 'extraction', h.id + '.json'), JSON.stringify(rec, null, 1) + '\n');
  }
  const info = { schema: 'blind1-run-1.1', run_at: new Date().toISOString(), node: process.version, base_commit: head, program_manifest_sha256: C.sha256File(arg('manifest')), freeze_sha256: frz ? C.sha256File(arg('freeze')) : null, technical_test: !frz, histories: gold.histories.length };
  fs.writeFileSync(path.join(out, 'run-info.json'), JSON.stringify(info, null, 1) + '\n');
  console.log(`прогон выполнен: ${gold.histories.length} историй → ${out}`);
}
main().catch(e => { console.error(e); process.exit(1); });
