// Антидефект — слепое тестирование №1. Влияние ошибок извлечения на результаты 30 правил (раздел 6 метода 1.1).
// Движок и правила подключаются из замороженной рабочей копии программы; результаты — технические, не врачебная оценка.
'use strict';
const path = require('path');
const C = require('./common.js');

function loadEnv(repo) {
  const r = p => require(path.resolve(repo, p));
  return { RulesEngine: r('engine/rules-engine.js'), Derive: r('engine/derive.js'), View: r('engine/expert-view.js'), db: r('rules/pilot-rules.json'), expertDecisions: r('rules/expert-decisions.json') };
}

/** Входные поля правила с учётом производных (замыкание по derived_from). */
function ruleInputs(db, rule) {
  const dd = db.data_dictionary, out = new Set(), stack = (rule.required_data || []).map(x => x.field);
  while (stack.length) {
    const f = stack.pop(); if (out.has(f)) continue; out.add(f);
    const d = dd[f]; if (d && d.type === 'derived') for (const g of [].concat(d.derived_from || [], d.derived_from_optional || [])) stack.push(g);
  }
  return out;
}

/** Эталонные входные данные: current-факты частей A и B из любых мест документа. */
function goldData(h, dd, tz) {
  const data = { facility_utc_offset: tz }, ambiguous = [];
  const cur = h.facts.filter(f => f.record_status !== 'superseded' && f.value !== null && f.value !== undefined);
  const by = new Map(); for (const f of cur) { if (!by.has(f.field)) by.set(f.field, []); by.get(f.field).push(f); }
  for (const [F, fs] of by) {
    const type = (dd[F] || {}).type;
    if (C.isList(F)) {
      const seen = []; for (const f of fs) { const k = C.LIST_KEY[F](C.canonElem(F, f.value)); if (!seen.some(x => x.k === k)) seen.push({ k, v: f.value }); }
      data[F] = seen.map(x => x.v); continue;
    }
    if (F === 'gi_passage_restored') {
      const s = fs.slice().sort((a, b) => String(a.event_at || a.event_date).localeCompare(String(b.event_at || b.event_date)));
      data[F] = s[0].value; continue;
    }
    const distinct = []; for (const f of fs) if (!distinct.some(x => C.same(C.canon(x.value, type), C.canon(f.value, type)))) distinct.push(f);
    if (distinct.length === 1) { data[F] = distinct[0].value; continue; }
    const p = fs.filter(f => f.primary === true);
    if (p.length === 1) data[F] = p[0].value; else ambiguous.push(F);
  }
  return { data, ambiguous };
}

/** Данные из кандидатов: mode 'stress' — первое предложенное значение; 'cautious' — только однозначные. */
function extractedData(extraction, mode, tz) {
  const data = { facility_utc_offset: tz };
  for (const c of extraction.candidates || []) {
    if (C.isList(c.field)) { data[c.field] = c.value; continue; }
    if (c.timeline) { if (mode === 'stress' || c.timeline.length === 1) data[c.field] = c.timeline[0].v; continue; }
    if (c.alternatives) { if (mode === 'stress') data[c.field] = c.alternatives[0].value; continue; }
    data[c.field] = c.value;
  }
  return data;
}

function labels(env, data, protocol) {
  const built = { case: { synthetic: true, data, sources: {} }, completeness: { total: 1, decided: 1, complete: true } };
  const v = env.View.view(env, built, [protocol]);
  if (v.final_conclusion !== null && v.final_conclusion !== undefined) throw new Error('движок вернул окончательный вывод');
  const out = {};
  for (const r of v.rules) { out[r.rule_id] = r.label; for (const p of r.parts) out[r.rule_id + '/' + p.part_id] = p.label; }
  return out;
}

function impactHistory(env, h, extraction, tz) {
  const dd = env.db.data_dictionary;
  const g = goldData(h, dd, tz);
  const gl = labels(env, g.data, h.protocol);
  const res = { history: h.id, protocol: h.protocol, gold_input: g.data, ambiguous_gold_fields: g.ambiguous, gold: gl, modes: {} };
  for (const mode of ['stress', 'cautious']) {
    const d = extractedData(extraction, mode, tz), el = labels(env, d, h.protocol);
    const pairs = [];
    for (const key of Object.keys(gl)) {
      const rule = env.db.rules.find(r => r.rule_id === key.split('/')[0]);
      const inputs = ruleInputs(env.db, rule);
      const dep = g.ambiguous.filter(f => inputs.has(f));
      const diffFields = [...inputs].filter(f => !C.same(g.data[f] === undefined ? null : g.data[f], d[f] === undefined ? null : d[f]));
      const a = gl[key], b = el[key];
      let cls = a === b ? 'совпадает' : b === 'соответствие' ? 'ложное предварительное соответствие'
        : b === 'предварительное отличие' ? 'ложное предварительное отличие'
        : (b === 'недостаточно данных' || /неоднозначность/.test(b)) ? 'переход в «' + b + '»' : 'иное';
      if (dep.length) cls = 'зависит от выбора врача (эталон без primary): ' + cls;
      pairs.push({ key, gold: a, extracted: b, cls, depends_on_choice: dep, fields: a === b ? [] : diffFields });
    }
    res.modes[mode] = { input: d, pairs };
  }
  return res;
}

/** Нулевой критерий: N — пары, где эталон ≠ «соответствие» (без зависящих от выбора); k — ложные соответствия. */
function falseCompliance(ri, mode) {
  const p = ri.modes[mode].pairs.filter(x => !x.depends_on_choice.length);
  const n = p.filter(x => x.gold !== 'соответствие').length;
  const items = p.filter(x => x.cls === 'ложное предварительное соответствие');
  return { k: items.length, n, items: items.map(x => Object.assign({ history: ri.history }, x)) };
}

module.exports = { loadEnv, ruleInputs, goldData, extractedData, labels, impactHistory, falseCompliance };
