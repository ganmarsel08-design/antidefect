// Проверка оценки влияния на правила (технические данные; движок — замороженная рабочая копия программы).
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const I = require('../impact.js');
const REPO = process.env.ANTIDEFECT_REPO || '/home/claude/antidefect';
const env = I.loadEnv(REPO);
const F = (fid, field, value, extra) => Object.assign({ fid, field, value, quote: 'х', location: 'body', record_status: 'current' }, extra || {});
const base = [F('1', 'gestational_age_weeks', 29), F('2', 'rds_diagnosed', true), F('3', 'rds_risk', true), F('4', 'cpap_from_birth', true)];
const h = facts => ({ id: 'ТЕХ', protocol: 'РДС', facts });
const cand = (field, value, alts) => alts ? { id: field, field, alternatives: alts.map(v => ({ value: v, fragments: [] })) } : { id: field, field, value, fragments: [] };
const ext = (...c) => ({ candidates: [cand('gestational_age_weeks', 29), cand('rds_diagnosed', true), cand('rds_risk', true), cand('cpap_from_birth', true), ...c] });

test('неверно извлечённое давление даёт ложное предварительное соответствие RDS-001', () => {
  const r = I.impactHistory(env, h([...base, F('5', 'cpap_pressure_cmh2o', 5)]), ext(cand('cpap_pressure_cmh2o', 6)), '+05:00');
  assert.equal(r.gold['RDS-001'], 'предварительное отличие');
  const p = r.modes.stress.pairs.find(x => x.key === 'RDS-001');
  assert.equal(p.cls, 'ложное предварительное соответствие'); assert.ok(p.fields.includes('cpap_pressure_cmh2o'));
  assert.equal(I.falseCompliance(r, 'stress').k, 1);
});

test('альтернативы: стресс берёт первую (ложное соответствие), осторожный — нет данных', () => {
  const r = I.impactHistory(env, h([...base, F('5', 'cpap_pressure_cmh2o', 5)]), ext(cand('cpap_pressure_cmh2o', null, [6, 5])), '+05:00');
  assert.equal(r.modes.stress.pairs.find(x => x.key === 'RDS-001').cls, 'ложное предварительное соответствие');
  assert.match(r.modes.cautious.pairs.find(x => x.key === 'RDS-001').cls, /недостаточно данных/);
  assert.equal(I.falseCompliance(r, 'cautious').k, 0);
});

test('эталон: primary выбирает значение; без primary поле неоднозначно и пары исключаются из нулевого критерия', () => {
  const two = [F('5', 'cpap_pressure_cmh2o', 5, { primary: true }), F('6', 'cpap_pressure_cmh2o', 7)];
  assert.equal(I.goldData(h([...base, ...two]), env.db.data_dictionary, '+05:00').data.cpap_pressure_cmh2o, 5);
  const amb = [F('5', 'cpap_pressure_cmh2o', 5), F('6', 'cpap_pressure_cmh2o', 7)];
  const r = I.impactHistory(env, h([...base, ...amb]), ext(cand('cpap_pressure_cmh2o', 6)), '+05:00');
  assert.deepEqual(r.ambiguous_gold_fields, ['cpap_pressure_cmh2o']);
  assert.match(r.modes.stress.pairs.find(x => x.key === 'RDS-001').cls, /^зависит от выбора врача/);
  assert.equal(I.falseCompliance(r, 'stress').k, 0);
});

test('устаревшие записи эталона в данные не попадают', () => {
  const g = I.goldData(h([...base, F('5', 'cpap_pressure_cmh2o', 4, { record_status: 'superseded' }), F('6', 'cpap_pressure_cmh2o', 6)]), env.db.data_dictionary, '+05:00');
  assert.equal(g.data.cpap_pressure_cmh2o, 6); assert.deepEqual(g.ambiguous, []);
});
